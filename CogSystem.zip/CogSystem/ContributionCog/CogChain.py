import os
import re
os.environ["OPENAI_API_KEY"]='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'
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
llm = ChatOpenAI(model="gpt-4-0125-preview")
import random
import sys
from CogAgent import CogAgent

class CogChain:
    def __init__(self, cog_agent):
        self.cog_agent = cog_agent
        self.convo_history = []
        self.name = cog_agent.name


    def kb_print(self, kb):
        kb_str = "KNOWLEDGE BASE:\n"
        for item in kb:
            item_str = f"{item['item']}\n\n"
            kb_str += item_str
        return kb_str

    def preference_chain(self, task, kb, decision_options):
        kb_string = self.kb_print(kb)
        update_goal = PromptTemplate(
            input_variables = ["task","updated_kb", "decision_options"],
            template = """{task}. You have access to a list of facts, called a 'knowledge base', to help guide your preference. Here is the most recently updated list:
            {updated_kb}
            Based on the above facts, choose one alternative from the decision options. You must choose from the provided options only. 
            {decision_options}
            Use this format for your output: PREFERENCE: (Insert candidate name) \n EXPLANATION: (justify your decision, limit to 300 tokens).""")
        goal_update = LLMChain(llm=llm, prompt=update_goal)
        updated_goal = goal_update.invoke({
        "task": task,
        "updated_kb": kb_string,
        "decision_options": decision_options})
        goal_match = re.search(r'PREFERENCE: (.+)', updated_goal['text'])
        if goal_match:
            new_goal = goal_match.group(1)
            self.cog_agent.preference = new_goal
        return updated_goal["text"]
    
    def contribution_chain(self, task, context):
        kb = self.cog_agent.knowledge_base
        kb_string = self.kb_print(kb)
        generate_contribution = PromptTemplate(
            input_variables = ["goal", "task", "kb", "context"],
            template = """{task} Your team mate just contributed: {context}.
                It is your turn in the discussion. Choose a fact from the knowledge base and provide it (exactly as phrased) alongside your response. You are likely to choose a fact that aligns with your preference. Your must directly respond to the contribution made by your teammate. Do not discuss any other fact from your knowledge base, aside from your chosen fact and your teammates contribution, in your response.
                Preference: {goal}
                {kb}
                Output format: INFORMATION ITEM: (insert fact exactly as given) \n COMMENTARY: (insert response)""")
        gen_contribution = LLMChain(llm=llm, prompt=generate_contribution)
        contribution = gen_contribution.invoke({
            "goal": self.cog_agent.preference,
            "task": task,
            "kb" : kb_string,
            "context": context})
        return contribution['text']

    def contribute_query(self, task, context):
        contribute_query = PromptTemplate(
            input_variables = ["task", "context", "preference"],
            template = """{task}. Your teammate just contributed: {context}
            Determine whether you would like to respond to this contribution based on your preference. 
            Preference: {preference}
            Use this format for your output: CONTRIBUTE: (insert YES/NO) \n EXPLANATION: (explain why you want to respond to your teammate (max 150 tokens)""")
        query = LLMChain(llm=llm, prompt=contribute_query)
        query_result = query.invoke({
            "task" : task,
            "context": context,
            "preference": self.cog_agent.preference
            })
        query_match = re.search(r'CONTRIBUTE: (.+)', query_result['text'])
        if query_match:
            yesORno = query_match.group(1)
            self.cog_agent.contribute = yesORno
        return query_result["text"]
        
    def process_message(self, task, context, decision_options):
        #Initial Snap
        initial_snap = self.cog_agent.state_snap()
        #Take in Context, Update KB
        self.knowledge_base_chain(context)
        #Update Goal
        goal_result = self.preference_chain(task, self.cog_agent.knowledge_base, decision_options)
        #Final Snap
        final_snap = self.cog_agent.state_snap()
        contribute = self.contribute_query(task, context)
        #Generate process report
        process_report = f"---------PROCESS REPORT----------\n"
        process_report += f"Initial Agent State: " + initial_snap + "\n"
        process_report += f"***\n"
        process_report += f"Context: " + context + "\n"
        process_report += f"***\n"
        process_report += f"Final Agent State: " + final_snap + "\n"
        process_report += f""+ goal_result + "\n"
        process_report += f"Want to Respond?\n"
        process_report += f""+ contribute + "\n"
        self.cog_agent.update_agent_state(process_report)

    def knowledge_base_chain(self, context):
        match = re.search(r'INFORMATION ITEM: (.+)', context)
        if match:
            info_item = match.group(1)
        else:
            print("ERROR: No Info Item")
            return

        # Find if the item is in the knowledge base
        item_found = False
        for item in self.cog_agent.knowledge_base:
            if item['item'] == info_item:
                item['frequency'] += 1
                item_found = True
                break
        
        # If the item is not found, add it to the knowledge base
        if not item_found:
            self.cog_agent.knowledge_base.append({"item": info_item, "frequency": 1, "initial": False})
        
        # Use kb_print to get the updated knowledge base string
        updated_kb_str = self.kb_print(self.cog_agent.knowledge_base)
        return updated_kb_str

    def first_turn_contribution(self, discussion_task):
        initial_snap = self.cog_agent.state_snap()
        goal = self.cog_agent.preference
        knowledge_base = self.cog_agent.knowledge_base
        kb_string = self.kb_print(knowledge_base)
        generate_first_turn_contribution = PromptTemplate(
            input_variables = ["goal", "kb", "task", "context"],
            template = """{task}. You are starting the discussion. Choose a fact from the knowledge base and provide it (exactly as phrased) alongside your commentary. You are likely to choose a fact that aligns with your preference.
            Preference: {goal}
            {kb}
            Output format: INFORMATION ITEM: (insert fact) \n COMMENTARY: (insert your commentary)""")
        gen_first_turn_contribution = LLMChain(llm=llm, prompt=generate_first_turn_contribution)
        contribution = gen_first_turn_contribution.invoke({
            "goal": goal,
            "kb": kb_string,
            "task": discussion_task})
        #updated_kb = self.knowledge_base_chain(contribution['text'])
        final_snap = self.cog_agent.state_snap()
        #Generate state report
        state_report = f"Contribution: " + contribution['text'] + "\n"
        state_report += f"--------------------------------------\n"
        state_report += f"Final Agent State: " + final_snap + "\n"
        self.cog_agent.update_agent_state(state_report)
        return contribution['text']

    def invoke_convo(self, sample_context, discussion_task):
        kb = self.cog_agent.knowledge_base
        goal = self.cog_agent.preference
        contribution_result = self.contribution_chain(discussion_task,sample_context)
        #updated_kb = self.knowledge_base_chain(contribution_result)
        ###GENERATE TURN REPORT
        final_snap = self.cog_agent.state_snap()
        self.cog_agent.update_agent_state(final_snap)
        return contribution_result
