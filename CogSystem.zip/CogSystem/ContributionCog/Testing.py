####IMPORTS####
import os
import re
os.environ["OPENAI_API_KEY"]='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'
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
llm = ChatOpenAI(model="gpt-4-0125-preview")

####INFO PROFILE####
# Anders
AG1 = """Astronaut Anders received the highest possible scores on the military survival standards, an assessment that all astronauts must complete in order to qualify for space missions. Anders' scores were significantly higher than either candidate’s scores."""
AG2 = """During Ander’s last ICE (Isolated and Confined in Extreme environments) training sequence, a fellow crew member praised him for being able to recognize others’ personal needs. In particular, he was recognized for facilitating personal time and bringing the group together for light-hearted fun."""
AG3 = """While working at NASA, Anders coordinated and completed a number of science projects. This expertise is important to Flight Engineers and one of the reasons Anders was chosen for the previous space mission. Anders did not disappoint. His ability to set up and coordinate science projects allowed his crew to finish more than twice the number of projects than anticipated."""
AG4 = """Anders was one of 8 hikers to successfully summit Mount Everest in 2005. Interviews with his comrades suggest Anders was the “glue” that held the group together when things went wrong."""
AG5 = """On previous missions, where lack of sleep was a frequent occurrence, Anders was largely unaffected. Despite the sub-optimal sleeping patterns, Anders' mental and physical health did not show signs of suffering."""
AG6 = """Data collected during training on simulated emergencies shows that Anders is able to remain calm during stressful and unexpected situations. He performs well under pressure."""
AB1 = """Anders suffered a broken wrist 7 months ago during a training simulation. The injury has healed, but will likely require extra exercise to prevent forearm muscle atrophy in zero gravity. This may take time away from him performing other team duties."""
AB2 = """Most of Anders' space training experience has been limited to simulations on Earth, with only one mission to the International Space Station. Furthermore, this mission to Mars would be even longer than his only long-distance flight experience--it is not clear if he will adapt well for a long-duration mission."""
AB3 = """Anders comes from a close-knit family. In diaries collected during training, he reported feeling sad and frustrated when he was unable to communicate with family members on a regular basis. This could be a serious concern for his mental health on a mission to Mars because there will be very little contact with Earth, and the little contact there is will be through mission control."""
AB4 = """Anders easily gets annoyed when explaining concepts to others and becomes very short with them as a result."""
AN1 = """Anders enjoys science fiction literature and has self-published a novel about the start of a human colony in a distant galaxy. He hopes to write a sequel when he retires."""
AN2 = """As a child, Anders enjoyed attending Houstonli-area sporting events with his parents. He was particularly fond of attending the Texans football games."""
AN3 = """Anders has a pet cat named Buzz, after Buzz Aldrin. Anders met Buzz as a child around when he decided he wanted to be an astronaut."""
AN4 = """Anders used to own a Brown Labrador Retriever named Bailey. When Anders participated in astronaut training and missions, Bailey used to stay with his family."""

# Bean
BG1 = """On Expedition 31/32, where he helped refuel the International Space Station (ISS), Bean encountered a breakdown in the communication system between his vehicle and the ISS before arrival to the ISS. Bean was credited for leading the extravehicular activity that identified and fixed the issue, ultimately making the refuel possible."""
BG2 = """While it is widely known that Bean holds a bachelor’s degree in Aerospace Engineering and Cross-Cultural studies, few know that he also pursued a minor in Counseling Psychology. Crewmembers have reported that Bean is a great listener and often knows exactly what to say to make others feel more comfortable."""
BG3 = """Survey responses from Bean’s previous crew mates reveal that he has a universal sense of humor. People always understand enjoy Bean’s jokes, so there is little risk of his humor being misinterpreted as being negative. Crew members report that this really helps to de-escalate tense situations."""
BB1 = """Bean had a difficult time getting along with some of his co-workers at Ames. He had asked his supervisor to intervene on several occasions as they were not able to resolve the disagreements on their own."""
BB2 = """Bean does not always plan his work well, and sometimes his pace of work is too slow. This has become problematic not only in his mission to the ISS, but also in training simulations. Often times, the maintenance work and data collection the astronauts engage in on these missions requires high levels of interdependency - this can be jeopardized if one person works at a slower pace than the rest of the crew members."""
BB3 = """Bean has a 2-year-old daughter, and colleagues have noticed he is frustrated when he has to work late and cannot be home with her. There is worry that being away for so long on this mission will exponentially increase Bean's frustration."""
BN1 = """Bean enjoys listening to the Beatles while performing work on his own.""" 
BN2 = """Bean is an avid fan of Shakespeare and often quotes his work."""
BN3 = """In college, Bean was on the squash team, where he met his best friend Jack. Jack now lives in Providence, Rhode Island, but they still talk on a weekly basis."""
BN4 = """Astronaut Bean enjoys traveling and his favorite place to vacation to is in the south of France."""
BN5 = """Bean has five siblings: one older brother, one older sister, and three younger sisters. He is closest to his younger sister, Rebecca, who is just one year younger than he is."""
BN6 = """If chosen for this mission, Bean would be the shortest crew member at 5-feet, 5-inches tall."""

# Collins
CG1 = """Collins is accustomed to being isolated for long periods of time. He successfully completed two treks to the Antarctic in which he lived in tents and a small building for the Antarctic winter-over period. Living in small spaces did not bother him."""
CG2 = """Collins has a passion for languages. He is fluent in English, Spanish, and French and proficient in Russian. Recently he started a class on Mandarin and already he is nearly proficient. This ability will help him interact and bond with international crew members."""
CG3 = """Collins has participated in spacewalks to repair damaged solar panels and ammonia pump module. His peers have ranked him as the most competent crew member during their spacewalks."""
CG4 = """Collins received the “Silver Snoopy” award for his contributions on NASA’s STS-135 mission. This award is considered to be the highest honor of all of the awards, given to the person who was the most outstanding team member, creating a team environment focused on flight safety and overall team success."""
CB1 = """Surveys showed that Collins has snapped at coworkers on multiple occasions. In one situation, a crewmember even went so far as to say would not want to work with Collins on future missions."""
CB2 = """Collins has the least space-related training of all three potential candidates."""
CB3 = """Recent blood work indicated that Collins may be developing above-average blood pressure. Doctors advised another assessment before making any conclusive determinations. However, if Collins does have heightened blood pressure, he would have to take extra time to rest while on the mission. This would detract from his time working on experiments, as well as his ability to do physically stressful activities."""
CB4 = """Three weeks ago, Collins broke his ankle. As a result, he has not been training as much and the current state of his cardiovascular performance is behind compared to the other two candidates."""
CB5 = """In one incident during a mock extravehicular activity scenario, Collins refused to follow an instruction from mission control. Fellow crew members were unsure of why he did this since the request from mission control seemed straightforward and helpful. Crewmembers reported being conflicted with how to respond, which slowed their progress on the extravehicular activity scenario. Only half of the tasks needed were completed on the simulated extravehicular activity."""
CB6 = """An internal incident report indicates that Collins made offensive jokes to a Chinese astronaut on a previous analog space mission that made the Chinese astronaut and other crew members uncomfortable."""
CN1 = """Collins considers himself a coffee aficionado and his favorite brand of coffee is Intelligentsia."""
CN2 = """Collins’ childhood friend completed NASA’s astronaut candidate training program but was never selected for a space mission."""
CN3 = """Collins enjoys completing Sudoku puzzles to relax"""
CN4 = """Collins has a fraternal twin who works in finance in Houston, Texas."""

cmr_kb = CG1 + "\n\n" + CG2 + "\n\n" + CG3+ "\n\n" +CG4+ "\n\n" +CB4+ "\n\n" +CN1+ "\n\n" +CN2+ "\n\n" +BG1+ "\n\n" +BG2+ "\n\n" +BG3+ "\n\n" +BB2+ "\n\n" +BB3+ "\n\n" +BN1+ "\n\n" +BN2+ "\n\n" +AG2+ "\n\n" +AG6+ "\n\n" +AB1+ "\n\n" +AB2+ "\n\n" +AB3+ "\n\n" +AB4+ "\n\n" +AN1+ "\n\n" +AN2

#print(cmr_kb)

task = """DISCUSSION TASK: You work as a member of NASA’s Astronaut Crew Composition team. Your team analyzes all of the information obtained during astronaut selection and training - including test scores, analog performance measures, expert observations, peer evaluations, and medical  records. Armed with this information, your team makes two kinds of evaluations. The first evaluation is to determine which astronauts are ready for flight and which are not. Of those who are deemed to be flight ready, your team composes entire crews for each mission. In this second evaluation, you consider the complementarity and compatibility of the astronauts as a team to select the 4, 5, or 6  astronauts (depending on the mission) who will perform best as individuals, and as a crew. While composing crews for missions on the International Space Station has become routine, your team just received a special assignment from the Mission Planning Directorate that is anything but routine.  
The Mars mission has been fast-tracked. Instead of the 2033 launch date that NASA had been aiming for, the launch date is being moved up to 2020. Intensive crew training for this unprecedented and bold journey must begin immediately. A 5-member crew will embark on this 3 year journey to Mars. This a truly international endeavor: the Russian, European, Indian, and Chinese Space Agencies will each select one astronaut for the mission. NASA will select the 5th crew member - an American astronaut - to join this international crew.  
The crew members from the other countries have backgrounds in engineering, botany, geology and medicine. The crew still needs a flight engineer. 
Your team was able to quickly narrow the field down to three veteran astronauts: Anders, Bean, and Collins. Each of these three have experience as a flight engineer on the ISS, have the necessary basic technical skills for the flight engineer position, meet basic requirements for the mission including height, Body Mass Index, and have passed a mental health screening. Now that you know the other potential crew members it is necessary for your team to determine which of the crew members will be the greatest asset on this particular mission.  
The 3-year mission to Mars will be demanding. The success of the Mars mission will require the 5-person crew to live and work together in extremely close quarters, while isolated from the usual sources of social support - friends and family - for extended periods of time. It will require that the crew can adapt to the unknown and be able to handle whatever challenges will come their way. Once they arrive at Mars, the crew will have to complete complex feats such as landing and extravehicular activities. Because of a significant communication delay with Earth of up to 22 minutes each way, the crew will have to work autonomously. Additionally, the crew of the Mars mission consists of individuals representing multiple nationalities, making strong interpersonal skills all the more critical to the success of the mission.  
The international space consortium has agreed to announce the names of the crew members from each of the 5 countries in just 10 days from now. Your team must deliver a recommendation for whom should be the American astronaut; years of hard work (and millions of dollars) rest on this decision.  
To guide your difficult decision, you have compiled information from the personnel file for each candidate. The personnel files for each candidate are detailed and include information such as their performance scores and ranking on various training tasks, biographical information, evaluations and questionnaires completed by  supervisors and individuals with whom they worked on prior trainings and missions, and questionnaires completed by the candidate and his family. A few human resource assistant have been working through the personnel files and have prepared briefs for you. Your team must now come together and discuss who should be selected for the mission.   
Remember, the success of the mission to Mars depends on your team. Choose quickly, but wisely!
"""

context = """While it is widely known that Bean holds a bachelor�s degree in Aerospace Engineering and Cross-Cultural studies, few know that he also pursued a minor in Counseling Psychology. Crewmembers have reported that Bean is a great listener and often knows exactly what to say to make others feel more comfortable.

COMMENTARY: Though Collins' technical prowess and experience in spacewalks are indeed impressive and crucial for the Mars mission, we must not overlook the importance of psychological resilience and interpersonal skills in such a prolonged and isolated mission. Bean's unique educational background, combining Aerospace Engineering with Cross-Cultural studies and a minor in Counseling Psychology, equips him with a rare blend of technical knowledge and emotional intelligence. This combination is invaluable in maintaining crew morale and cohesion over the three-year journey. His ability to listen and provide comfort, as reported by crewmembers, will be essential in managing the psychological stresses of the mission. Furthermore, his universal sense of humor can help de-escalate tense situations, maintaining a positive working environment essential for the mission's success. In a mission where technical skills are a baseline requirement, Bean's additional psychological and interpersonal abilities could very well be the linchpin for mission success, making him an ideal candidate for the Mars mission.
"""

contribute_query = PromptTemplate(
    input_variables = ["task", "context", "preference"],
    template = """{task}. Your teammate just contributed: {context}
    Determine whether you would like to respond to this contribution based on your preference and personality.
    Preference: {preference}
    Personality: {personality}
    Use this format for your output: CONTRIBUTE: (insert YES/NO) \n EXPLANATION: (explain why you want to respond to your teammate (max 150 tokens)""")
query = LLMChain(llm=llm, prompt=contribute_query)
query_result = query.invoke({
    "task" : task,
    "context": context,
    "preference": "Scott Collins",
    "personality": "You are unadventurous, silent, inactive, timid, unassertive."
    })
query_match = re.search(r'CONTRIBUTE: (.+)', query_result['text'])
if query_match:
    yesORno = query_match.group(1)
    #self.cog_agent.contribute = yesORno
    print(yesORno)

print(query_result['text'])