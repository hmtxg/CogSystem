import subprocess
import os

# Confirm the current directory
current_dir = "C:\\Users\\Hanna\\OneDrive\\Desktop\\LangGraph\\BaseCog"
print("Current directory:", current_dir)

script_path = "C:\\Users\\Hanna\\OneDrive\\Desktop\\LangGraph\\BaseCog\\Discuss.py"

# Define the number of runs
num_runs = 1

# Loop to run Discuss.py multiple times
for i in range(num_runs):
    # Create a new directory for each run
    run_dir = os.path.join(current_dir, f"run_{i + 1}")

    # Set the new directory as the working directory for the subprocess
    os.makedirs(run_dir, exist_ok=True)
    os.chdir(run_dir)

    # Execute Discuss.py as a separate process
    subprocess.run(["python", script_path])

    # Move back to the original directory after the run
    os.chdir(current_dir)
