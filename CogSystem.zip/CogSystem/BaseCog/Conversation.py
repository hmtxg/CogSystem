import os
import re
import random
import sys
from Report import Report
from CogAgent import CogAgent
from CogChain import CogChain

class Conversation:
    def __init__(self, cog_agents, discussion_task, rounds, decision_options, decision_rule, knowledge_bank):
        self.cog_agents = cog_agents
        self.discussion_task = discussion_task
        self.rounds = rounds
        self.convo_history = []
        self.decision_options = decision_options
        self.decision_rule = decision_rule
        self.knowledge_bank = knowledge_bank
        self.report = Report(cog_agents, knowledge_bank)
        self.revealed_profile = []

    def broadcast_message(self, cog_agents, context, agent_in):
        for agent in cog_agents:
            if agent.name != agent_in:
                agent.process_message(self.discussion_task, context, self.decision_options)
    
    def update_revealed_profile(self, context, current_agent, round):
        match = re.search(r'INFORMATION ITEM: (.+)', context)
        if match:
            info_item = match.group(1)
        else:
            print("ERROR: No Info Item")
            return
        
        rp = [{"item": info_item,
            "agent": current_agent.name,
            "round": round}]

        info_item_label = self.report.kb_map(rp, self.knowledge_bank)
        # Add the info_item to the revealed_profile
        self.revealed_profile.append({
            "item": info_item_label[0],
            "agent": current_agent.name,
            "round": round})
        return self.revealed_profile
              
    def consensus(self):
        # Check for consensus based on the decision_rule
        if self.decision_rule == 'unanimous':
            # Check if all agents have the same goal
            goals = {agent.cog_agent.preference for agent in self.cog_agents}
            if len(goals) == 1:
                return goals.pop()  # Return the agreed-upon goal
            else:
                return 'NO CONSENSUS'
        elif self.decision_rule == 'majority':
            # Check if there is a majority agreement on the goal
            goal_counts = {agent.cog_agent.preference: 0 for agent in self.cog_agents}
            for agent in self.cog_agents:
                goal_counts[agent.cog_agent.preference] += 1

            max_goal = max(goal_counts, key=goal_counts.get)

            if goal_counts[max_goal] > len(self.cog_agents) / 2:
                return max_goal  # Return the agreed-upon goal
            else:
                return 'NO CONSENSUS'
        else:
            return 'NO CONSENSUS'

    def next_speaker(self, current_agent, broadcast_agents):
        next_speakers = [agent for agent in broadcast_agents]
        if next_speakers:
            # If more than 2+ agents, choose randomly
            next_speaker = random.choice(next_speakers)
        return next_speaker

    def run_convo(self):
        #initialize agent preferences
        for agent in self.cog_agents:
            # Call preference_chain for each agent
            preference = agent.preference_chain(
                self.discussion_task, agent.cog_agent.knowledge_base, self.decision_options)
            agent.cog_agent.update_agent_state(preference)

        # Store Initial Profiles
        self.report.initial_info_profiles = self.report.retrieve_info_profiles(self.cog_agents, self.knowledge_bank)

        # Store Initial Preferences
        self.report.initial_preferences = self.report.retrieve_preferences(self.cog_agents)

        # Initial Turn Contribution
        agent1 = random.choice(self.cog_agents)
        contribution1 = agent1.first_turn_contribution(self.discussion_task)
        agent1.cog_agent.frequency += 1
        
        # Add first contribution to chat history, ADD ITEM TO REVEALED_PROFILE
        self.convo_history.append(contribution1)
        self.update_revealed_profile(contribution1, agent1, 0)

        # Broadcast first contribution to other agents
        broadcast_agents = [agent for agent in self.cog_agents if agent != agent1]
        self.broadcast_message(broadcast_agents, contribution1, agent1.name)

        # Store Turn Preference
        self.report.turn_preferences[0] = self.report.retrieve_preferences(self.cog_agents)
        # Store Turn Info Profiles
        self.report.turn_info_profiles[0] = self.report.retrieve_info_profiles(self.cog_agents, self.knowledge_bank)

        print(agent1.name)
        print(contribution1)
        current_agent = self.next_speaker(agent1, broadcast_agents)
        
        for round_num in range(1, self.rounds):
            context = self.convo_history[-1]
            contribution = current_agent.invoke_convo(context, self.discussion_task)
            current_agent.cog_agent.frequency += 1
            print(current_agent.name)
            print(contribution)
            self.convo_history.append(contribution) 
            #ADD ITEM TO REVEALED PROFILE
            self.update_revealed_profile(contribution, current_agent, round_num)
            # Broadcast to other agents
            broadcast_agents = [agent for agent in self.cog_agents if agent != current_agent]
            self.broadcast_message(broadcast_agents, contribution, current_agent.name)
            # Store Turn Preference
            self.report.turn_preferences[round_num] = self.report.retrieve_preferences(self.cog_agents)
             # Store Turn Info Profiles
            self.report.turn_info_profiles[round_num] = self.report.retrieve_info_profiles(self.cog_agents, self.knowledge_bank)
            decision_result = self.consensus()
            if decision_result != 'NO CONSENSUS':
                print(f"Consensus reached! Agreed upon goal: {decision_result}")
                break  # Exit the loop if consensus is reached
            #IF agents do not agree, select next speaker
            current_agent = self.next_speaker(current_agent, broadcast_agents)  
        decision_result = self.consensus()
        # Store Final Preferences
        self.report.final_preferences = self.report.retrieve_preferences(self.cog_agents)
        # Store Final Info Profiles
        self.report.final_info_profiles = self.report.retrieve_info_profiles(self.cog_agents, self.knowledge_bank)
        # Store Agent Speaker Frequencies
        self.report.speaker_frequency = self.report.retrieve_agent_frequency(self.cog_agents)
        self.report.revealed_profile = self.revealed_profile
        # Calc & Store non-initial contribution %
        non_initial_percentages = {}
        for agent in self.cog_agents:
            agent_name = agent.cog_agent.name
            non_initial_percentage = self.report.calculate_non_initial_contributions_percentage(agent_name, self.revealed_profile)
            
            if non_initial_percentage is not None:
                non_initial_percentages[agent_name] = non_initial_percentage
        self.report.non_initial_contributions_percentages = non_initial_percentages
        # Generate Report
        self.report.generate_preference_report(decision_result, self.rounds, self.decision_rule)
        self.report.generate_analysis_report(decision_result)
        with open("conversation_log.txt", "w") as log_file:
            log_file.write("----- Conversation Thread -----\n")
            for i, entry in enumerate(self.convo_history, start=1):
                log_file.write(f"Turn {i}:\n{entry}\n")
