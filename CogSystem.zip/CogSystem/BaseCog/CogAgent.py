class CogAgent:
    def __init__(self, name, knowledge_base):
        self.name = name
        self.knowledge_base = knowledge_base
        self.initial_knowledge_base = knowledge_base.copy()
        self.preference = ""
        self.state = []
        self.frequency = 0
    
    def was_item_in_initial_kb(self, item):
        return any(entry['item'] == item for entry in self.initial_knowledge_base)

    def state_snap(self):
        snapshot = ""
        snapshot += f"Preference: {self.preference}\n"
        return snapshot

    def update_agent_state(self, state):
        self.state.append(state) 