from CogAgent import CogAgent
from CogChain import CogChain

class Report:
    def __init__(self, cog_agents, knowledge_bank):
        self.initial_preferences = []
        self.turn_preferences = {}
        self.final_preferences = []
        self.turn_info_profiles = {}
        self.initial_info_profiles = []
        self.final_info_profiles = []
        self.speaker_frequency = []
        self.revealed_profile = []
        self.non_initial_contributions_percentages = []
        self.cog_agents = cog_agents 
        self.knowledge_bank = knowledge_bank

    def retrieve_preferences(self, cog_agents):
        preferences = [f"{agent.cog_agent.name}: {agent.cog_agent.preference}" for agent in cog_agents]
        return preferences
    
    def aggregate_round_profile(self, revealed_profile):
        aggregated_profile = {}
        all_shared_items = set()  # To keep track of all items shared in the rounds
        item_frequencies = {}  # To track the frequency of each item

        for entry in revealed_profile:
            round_num = entry["round"]
            item = entry["item"]
            agent = entry["agent"]  # Include the contributing agent name

            if round_num not in aggregated_profile:
                aggregated_profile[round_num] = [(item, agent)]
            else:
                aggregated_profile[round_num].append((item, agent))

            all_shared_items.add(item)  # Add the item to the set

            # Update the frequency of the item
            item_frequencies[item] = item_frequencies.get(item, 0) + 1

        # Prepare a string to be used in the report
        result_str = "\n----- Turn Group Revealed Profile -----\n"
        for round_num, items_agents in sorted(aggregated_profile.items()):
            result_str += f"Round {round_num}:\n"
            for item, agent in items_agents:
                result_str += f"Info Item: {item}\nContributing Agent: {agent}\n"
            result_str += "\n"
        result_str += "\n----- Final Group Revealed Profile -----\n"
        # Include a list of all items shared in the rounds with frequency
        for item in all_shared_items:
            result_str += f"{item} (Frequency: {item_frequencies[item]})\n"
        return result_str
    
    def retrieve_agent_frequency(self, cog_agents):
        speaker_frequency = [f"{agent.cog_agent.name}: {agent.cog_agent.frequency}" for agent in cog_agents]
        return speaker_frequency
   
    def generate_analysis_report(self, discussion_result):
        with open("analysis_report.txt", "w") as analysis_file:
            analysis_file.write("*********************************************\n")
            analysis_file.write("ANALYSIS REPORT\n")
            analysis_file.write("*********************************************\n")

            # 1. Calculate percentage of revealed profile items that are in the knowledge bank
            all_shared_items = self.extract_all_shared_items()
            revealed_profile_percentage = self.calculate_revealed_profile_percentage(all_shared_items)
            analysis_file.write("REVEALED PROFILE:\n")
            analysis_file.write(f"{revealed_profile_percentage:.2f}%\n\n")

            # 2. Calculate percentage of preference changes
            preference_change_percentage = self.calculate_preference_changes()
            analysis_file.write("PREFERENCE CHANGES:\n")
            analysis_file.write(f"{preference_change_percentage:.2f}%\n\n")

            # 3. Speaker distribution
            speaker_distribution = self.calculate_speaker_distribution()
            analysis_file.write("SPEAKER DISTRIBUTION:\n")
            for agent, percentage in speaker_distribution.items():
                analysis_file.write(f"{agent}: {percentage:.2f}%\n")
            analysis_file.write("\n")

            # 4. Decision made and group optimality rating
            if discussion_result != 'NO CONSENSUS':
                # decision_made, group_optimality = self.calculate_decision_optimality(all_shared_items)
                group_optimality_revealed_profile = self.calculate_revealed_profile_optimality(all_shared_items, discussion_result)
                group_optimality_knowledge_bank = self.calculate_knowledge_bank_optimality(discussion_result)
                analysis_file.write("DECISION MADE:\n")
                analysis_file.write(f"Decision: {discussion_result}\n")
                analysis_file.write(f"Group Optimality (Revealed Profile): {group_optimality_revealed_profile}\n")
                analysis_file.write(f"Group Optimality (Knowledge Bank): {group_optimality['knowledge_bank']}\n")

                # Corrected individual optimality ratings
                
            else:
                analysis_file.write("No group decision made.\n")
                analysis_file.write("\nIndividual Optimality:\n")
                for agent_pref in self.final_preferences:
                    agent_name, preference = agent_pref.split(": ")
                    revealed_profile_optimality = self.calculate_revealed_profile_optimality(all_shared_items, preference)
                    knowledge_bank_optimality = self.calculate_knowledge_bank_optimality(preference)
                    analysis_file.write(f"{agent_name}:\n")
                    analysis_file.write(f"Revealed Profile: {revealed_profile_optimality}\n")
                    analysis_file.write(f"Knowledge Bank: {knowledge_bank_optimality}\n")
    
    def extract_all_shared_items(self):
        all_shared_items = set()
        for entry in self.revealed_profile:
            label = entry['item']
            for item in self.knowledge_bank:
                if item['label'] == label:
                    all_shared_items.add(item['label'])
                    break  # Stop searching once the item is found
        return all_shared_items
    
    def calculate_revealed_profile_percentage(self, all_shared_items):
    # Calculate the percentage of unique items in the revealed profile also in the knowledge bank
        unique_revealed_items = set(entry['item'] for entry in self.revealed_profile)
        total_revealed_items = len(unique_revealed_items)
        
        if total_revealed_items == 0:
            return 0.0
        
        kb_items = [entry['label'] for entry in self.knowledge_bank]
        kb_length = len(kb_items)
        
        percentage = (total_revealed_items / kb_length) * 100
        return percentage
    
    def calculate_preference_changes(self):
        initial_preferences = [agent.split(": ")[1] for agent in self.initial_preferences]
        final_preferences = [agent.split(": ")[1] for agent in self.final_preferences]
        changed_agents = [initial != final for initial, final in zip(initial_preferences, final_preferences)]
        return (sum(changed_agents) / len(self.cog_agents)) * 100
    
    def calculate_speaker_distribution(self):
        total_turns = sum([int(freq.split(": ")[1]) for freq in self.speaker_frequency])
        speaker_distribution = {freq.split(": ")[0]: (int(freq.split(": ")[1]) / total_turns) * 100 for freq in self.speaker_frequency}
        return speaker_distribution

    def calculate_revealed_profile_optimality(self, all_shared_items, agent_preference):
        ####FIX
        preference_counts = {'C': 0, 'A': 0, 'B': 0}
        for item in all_shared_items:
        # Check if the second item letter is 'G'
            if item[1] == 'G':
                # Determine the preference of the first item and update preference counts
                if item[0] == 'C':
                    preference_counts['C'] += 1
                elif item[0] == 'A':
                    preference_counts['A'] += 1
                elif item[0] == 'B':
                    preference_counts['B'] += 1
        preference_ranking = {'C': 0, 'A': 0, 'B': 0}
        for preference, count in preference_counts.items():
            preference_ranking[preference] = count
        sorted_preferences = sorted(preference_ranking.items(), key=lambda x: x[1], reverse=True)
        max_count = sorted_preferences[0][1]
        max_count_preferences = sum(1 for pref, count in sorted_preferences if count == max_count)
        ranks = {} 
        if max_count_preferences == 1:  # Only one preference has the maximum count
            for preference, count in sorted_preferences:
                ranks[preference] = 'BEST' if count == max_count else 'WORST'
        else:  # Multiple preferences have the maximum count
            for preference, count in sorted_preferences:
                ranks[preference] = 'AVERAGE' if count == max_count else 'WORST'
            
            # Calculate second highest count
        second_highest_count = sorted_preferences[1][1]
            # Calculate how many preferences have the second highest count
        second_highest_count_preferences = sum(1 for pref, count in sorted_preferences if count == second_highest_count)
            
            # Assign 'AVERAGE' rank to preferences with the second highest count
        if second_highest_count_preferences > 1:
            for preference, count in sorted_preferences:
                if count == second_highest_count:
                    ranks[preference] = 'AVERAGE'
            
            # Calculate lowest count
        lowest_count = sorted_preferences[-1][1]
            
            # If lowest count is different from second highest count, assign 'WORST' rank
        if lowest_count != second_highest_count:
            lowest_count_preferences = sum(1 for pref, count in sorted_preferences if count == lowest_count)
            if lowest_count_preferences > 1:
                for preference, count in sorted_preferences:
                    if count == lowest_count:
                        ranks[preference] = 'WORST'
            
            # Extract agent preference label
        agent_preference_label = agent_preference.split()[1][0]
            
            # Assign the agent's preference ranking
        agent_preference_ranking = ranks.get(agent_preference_label, None)
        return agent_preference_ranking

    def calculate_knowledge_bank_optimality(self, preference):
        # Define the fixed knowledge bank optimality ratings
        knowledge_bank_ratings = {'Samuel Anders': 'BEST', 'John Bean': 'AVERAGE', 'Scott Collins': 'WORST'}
        return knowledge_bank_ratings.get(preference, 'UNKNOWN')

    def generate_preference_report(self, discussion_result, rounds, decision_rule):
        with open("report.txt", "w") as report_file:
            report_file.write("*********************************************\n")
            report_file.write("DISCUSSION REPORT\n")
            report_file.write("*********************************************\n")
            report_file.write(f"Number of Rounds: {rounds}\n")
            report_file.write(f"Decision Rule: {decision_rule}\n")
            report_file.write
            if discussion_result == 'NO CONSENSUS':
                report_file.write(f"Discussion Result: Failure to reach consensus in the specified number of rounds.\n")
            else:
                report_file.write(f"Discussion Result: Consensus reached in {rounds} rounds!\n")
                report_file.write(f"Agreed upon goal: {discussion_result}\n")
            report_file.write("\n*********************************************\n")
            report_file.write("PREFERENCE INDICATORS\n")
            report_file.write("*********************************************\n")
            report_file.write("----- Initial Preference Distribution -----\n")
            for i, entry in enumerate(self.initial_preferences, start=1):
                report_file.write(f"{entry}\n")

            report_file.write("----- Turn Preference Distribution -----\n")
            for round_num, preferences in self.turn_preferences.items():
                report_file.write(f"Round {round_num}:\n")
                for i, entry in enumerate(preferences, start=1):
                    report_file.write(f"{entry}\n")
                report_file.write("\n")

            report_file.write("----- Final Preference Distribution -----\n")
            for i, entry in enumerate(self.final_preferences, start=1):
                report_file.write(f"{entry}\n")

            report_file.write("\n*********************************************\n")
            report_file.write("INFO ITEM INDICATORS\n")
            report_file.write("*********************************************\n")
            report_file.write("\n----- Initial Info Profiles -----\n")
            for i, entry in enumerate(self.initial_info_profiles, start=1):
                report_file.write(f"{entry}\n")

            report_file.write("\n----- Turn Info Profiles -----\n")
            for round_num, info_profile in self.turn_info_profiles.items():
                report_file.write(f"Round {round_num}:\n")
                for i, entry in enumerate(info_profile, start=1):
                    report_file.write(f"{entry}\n")
                report_file.write("\n")
            
            report_file.write("----- Final Info Profiles -----\n")
            for i, entry in enumerate(self.final_info_profiles, start=1):
                report_file.write(f"{entry}\n")

            aggregated_profile_str = self.aggregate_round_profile(self.revealed_profile)
            report_file.write(f"{aggregated_profile_str}\n")

            report_file.write("\n*********************************************\n")
            report_file.write("CONVO INDICATORS\n")
            report_file.write("*********************************************\n")
            report_file.write("-----Speaker Frequency -----\n")
            for i, entry in enumerate(self.speaker_frequency, start=1):
                report_file.write(f"{entry}\n") 
            report_file.write("\n----- Non-Initial Contributions-----\n")
            for agent_name, percentage in self.non_initial_contributions_percentages.items():
                report_file.write(f"{agent_name}: {percentage}%\n")
    
    def kb_map(self, knowledge_base, knowledge_bank):
        labels = []
        for kb_entry in knowledge_base:
            kb_item = kb_entry["item"]
            for bank_entry in knowledge_bank:
                bank_item = bank_entry["item"]
                if kb_item == bank_item:
                    labels.append(bank_entry["label"])
                    break  # Stop searching once a match is found
        return labels

    def retrieve_info_profiles(self, cog_agents, knowledge_bank):
        profiles = []
        for agent in cog_agents:
            knowledge_base = agent.cog_agent.knowledge_base
            profile_labels = self.kb_map(knowledge_base, knowledge_bank)
            profiles += [f"{agent.cog_agent.name}: {profile_labels}"]
        return profiles

    def calculate_non_initial_contributions_percentage(self, agent_name, revealed_profile):
        agent_contributions = [entry for entry in revealed_profile if entry['agent'] == agent_name]
        total_contributions = len(agent_contributions)

        if total_contributions == 0:
            return None  # Return None for agents who did not contribute

        non_initial_contributions = sum(
            1 for entry in agent_contributions if not self.is_item_in_initial_kb(agent_name, entry['item']))

        if total_contributions == non_initial_contributions:
            return 0.0  # All contributions were non-initial

        percentage = (non_initial_contributions / (total_contributions - non_initial_contributions)) * 100
        return round(percentage, 2)

    def is_item_in_initial_kb(self, agent_name, item):
        for agent in self.cog_agents:
            if agent.cog_agent.name == agent_name:
                return agent.cog_agent.was_item_in_initial_kb(item)
        return False