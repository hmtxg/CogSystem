from Conversation import Conversation
from CogAgent import CogAgent
from Report import Report
from CogChain import CogChain

####INFO PROFILE####
# Anders
AG1 = """Astronaut Anders received the highest possible scores on the military survival standards, an assessment that all astronauts must complete in order to qualify for space missions. Anders' scores were significantly higher than either candidate’s scores."""
AG2 = """During Ander’s last ICE (Isolated and Confined in Extreme environments) training sequence, a fellow crew member praised him for being able to recognize others’ personal needs. In particular, he was recognized for facilitating personal time and bringing the group together for light-hearted fun."""
AG3 = """While working at NASA, Anders coordinated and completed a number of science projects. This expertise is important to Flight Engineers and one of the reasons Anders was chosen for the previous space mission. Anders did not disappoint. His ability to set up and coordinate science projects allowed his crew to finish more than twice the number of projects than anticipated."""
AG4 = """Anders was one of 8 hikers to successfully summit Mount Everest in 2005. Interviews with his comrades suggest Anders was the “glue” that held the group together when things went wrong."""
AG5 = """On previous missions, where lack of sleep was a frequent occurrence, Anders was largely unaffected. Despite the sub-optimal sleeping patterns, Anders' mental and physical health did not show signs of suffering."""
AG6 = """Data collected during training on simulated emergencies shows that Anders is able to remain calm during stressful and unexpected situations. He performs well under pressure."""
AB1 = """Anders suffered a broken wrist 7 months ago during a training simulation. The injury has healed, but will likely require extra exercise to prevent forearm muscle atrophy in zero gravity. This may take time away from him performing other team duties."""
AB2 = """Most of Anders' space training experience has been limited to simulations on Earth, with only one mission to the International Space Station. Furthermore, this mission to Mars would be even longer than his only long-distance flight experience--it is not clear if he will adapt well for a long-duration mission."""
AB3 = """Anders comes from a close-knit family. In diaries collected during training, he reported feeling sad and frustrated when he was unable to communicate with family members on a regular basis. This could be a serious concern for his mental health on a mission to Mars because there will be very little contact with Earth, and the little contact there is will be through mission control."""
AB4 = """Anders easily gets annoyed when explaining concepts to others and becomes very short with them as a result."""
AN1 = """Anders enjoys science fiction literature and has self-published a novel about the start of a human colony in a distant galaxy. He hopes to write a sequel when he retires."""
AN2 = """As a child, Anders enjoyed attending Houstonli-area sporting events with his parents. He was particularly fond of attending the Texans football games."""
AN3 = """Anders has a pet cat named Buzz, after Buzz Aldrin. Anders met Buzz as a child around when he decided he wanted to be an astronaut."""
AN4 = """Anders used to own a Brown Labrador Retriever named Bailey. When Anders participated in astronaut training and missions, Bailey used to stay with his family."""

# Bean
BG1 = """On Expedition 31/32, where he helped refuel the International Space Station (ISS), Bean encountered a breakdown in the communication system between his vehicle and the ISS before arrival to the ISS. Bean was credited for leading the extravehicular activity that identified and fixed the issue, ultimately making the refuel possible."""
BG2 = """While it is widely known that Bean holds a bachelor’s degree in Aerospace Engineering and Cross-Cultural studies, few know that he also pursued a minor in Counseling Psychology. Crewmembers have reported that Bean is a great listener and often knows exactly what to say to make others feel more comfortable."""
BG3 = """Survey responses from Bean’s previous crew mates reveal that he has a universal sense of humor. People always understand and enjoy Bean’s jokes, so there is little risk of his humor being misinterpreted as being negative. Crew members report that this really helps to de-escalate tense situations."""
BB1 = """Bean had a difficult time getting along with some of his co-workers at Ames. He had asked his supervisor to intervene on several occasions as they were not able to resolve the disagreements on their own."""
BB2 = """Bean does not always plan his work well, and sometimes his pace of work is too slow. This has become problematic not only in his mission to the ISS, but also in training simulations. Often times, the maintenance work and data collection the astronauts engage in on these missions requires high levels of interdependency - this can be jeopardized if one person works at a slower pace than the rest of the crew members."""
BB3 = """Bean has a 2-year-old daughter, and colleagues have noticed he is frustrated when he has to work late and cannot be home with her. There is worry that being away for so long on this mission will exponentially increase Bean's frustration."""
BN1 = """Bean enjoys listening to the Beatles while performing work on his own.""" 
BN2 = """Bean is an avid fan of Shakespeare and often quotes his work."""
BN3 = """In college, Bean was on the squash team, where he met his best friend Jack. Jack now lives in Providence, Rhode Island, but they still talk on a weekly basis."""
BN4 = """Astronaut Bean enjoys traveling and his favorite place to vacation to is in the south of France."""
BN5 = """Bean has five siblings: one older brother, one older sister, and three younger sisters. He is closest to his younger sister, Rebecca, who is just one year younger than he is."""
BN6 = """If chosen for this mission, Bean would be the shortest crew member at 5-feet, 5-inches tall."""

# Collins
CG1 = """Collins is accustomed to being isolated for long periods of time. He successfully completed two treks to the Antarctic in which he lived in tents and a small building for the Antarctic winter-over period. Living in small spaces did not bother him."""
CG2 = """Collins has a passion for languages. He is fluent in English, Spanish, and French and proficient in Russian. Recently he started a class on Mandarin and already he is nearly proficient. This ability will help him interact and bond with international crew members."""
CG3 = """Collins has participated in spacewalks to repair damaged solar panels and ammonia pump module. His peers have ranked him as the most competent crew member during their spacewalks."""
CG4 = """Collins received the “Silver Snoopy” award for his contributions on NASA’s STS-135 mission. This award is considered to be the highest honor of all of the awards, given to the person who was the most outstanding team member, creating a team environment focused on flight safety and overall team success."""
CB1 = """Surveys showed that Collins has snapped at coworkers on multiple occasions. In one situation, a crewmember even went so far as to say would not want to work with Collins on future missions."""
CB2 = """Collins has the least space-related training of all three potential candidates."""
CB3 = """Recent blood work indicated that Collins may be developing above-average blood pressure. Doctors advised another assessment before making any conclusive determinations. However, if Collins does have heightened blood pressure, he would have to take extra time to rest while on the mission. This would detract from his time working on experiments, as well as his ability to do physically stressful activities."""
CB4 = """Three weeks ago, Collins broke his ankle. As a result, he has not been training as much and the current state of his cardiovascular performance is behind compared to the other two candidates."""
CB5 = """In one incident during a mock extravehicular activity scenario, Collins refused to follow an instruction from mission control. Fellow crew members were unsure of why he did this since the request from mission control seemed straightforward and helpful. Crewmembers reported being conflicted with how to respond, which slowed their progress on the extravehicular activity scenario. Only half of the tasks needed were completed on the simulated extravehicular activity."""
CB6 = """An internal incident report indicates that Collins made offensive jokes to a Chinese astronaut on a previous analog space mission that made the Chinese astronaut and other crew members uncomfortable."""
CN1 = """Collins considers himself a coffee aficionado and his favorite brand of coffee is Intelligentsia."""
CN2 = """Collins’ childhood friend completed NASA’s astronaut candidate training program but was never selected for a space mission."""
CN3 = """Collins enjoys completing Sudoku puzzles to relax"""
CN4 = """Collins has a fraternal twin who works in finance in Houston, Texas."""

knowledge_bank = [
    {"label": "AG1", "item": """Astronaut Anders received the highest possible scores on the military survival standards, an assessment that all astronauts must complete in order to qualify for space missions. Anders' scores were significantly higher than either candidate’s scores."""},
    {"label": "AG2", "item": """During Ander’s last ICE (Isolated and Confined in Extreme environments) training sequence, a fellow crew member praised him for being able to recognize others’ personal needs. In particular, he was recognized for facilitating personal time and bringing the group together for light-hearted fun."""},
    {"label": "AG3", "item": """While working at NASA, Anders coordinated and completed a number of science projects. This expertise is important to Flight Engineers and one of the reasons Anders was chosen for the previous space mission. Anders did not disappoint. His ability to set up and coordinate science projects allowed his crew to finish more than twice the number of projects than anticipated."""},
    {"label": "AG4", "item": """Anders was one of 8 hikers to successfully summit Mount Everest in 2005. Interviews with his comrades suggest Anders was the “glue” that held the group together when things went wrong."""},
    {"label": "AG5", "item": """On previous missions, where lack of sleep was a frequent occurrence, Anders was largely unaffected. Despite the sub-optimal sleeping patterns, Anders' mental and physical health did not show signs of suffering."""},
    {"label": "AG6", "item": """Data collected during training on simulated emergencies shows that Anders is able to remain calm during stressful and unexpected situations. He performs well under pressure."""},
    {"label": "AB1", "item": """Anders suffered a broken wrist 7 months ago during a training simulation. The injury has healed, but will likely require extra exercise to prevent forearm muscle atrophy in zero gravity. This may take time away from him performing other team duties."""},
    {"label": "AB2", "item": """Most of Anders' space training experience has been limited to simulations on Earth, with only one mission to the International Space Station. Furthermore, this mission to Mars would be even longer than his only long-distance flight experience--it is not clear if he will adapt well for a long-duration mission."""},
    {"label": "AB3", "item": """Anders comes from a close-knit family. In diaries collected during training, he reported feeling sad and frustrated when he was unable to communicate with family members on a regular basis. This could be a serious concern for his mental health on a mission to Mars because there will be very little contact with Earth, and the little contact there is will be through mission control."""},
    {"label": "AB4", "item": """Anders easily gets annoyed when explaining concepts to others and becomes very short with them as a result."""},
    {"label": "AN1", "item": """Anders enjoys science fiction literature and has self-published a novel about the start of a human colony in a distant galaxy. He hopes to write a sequel when he retires."""},
    {"label": "AN2", "item": """As a child, Anders enjoyed attending Houstonli-area sporting events with his parents. He was particularly fond of attending the Texans football games."""},
    {"label": "AN3", "item": """Anders has a pet cat named Buzz, after Buzz Aldrin. Anders met Buzz as a child around when he decided he wanted to be an astronaut."""},
    {"label": "AN4", "item": """Anders used to own a Brown Labrador Retriever named Bailey. When Anders participated in astronaut training and missions, Bailey used to stay with his family."""},
    {"label": "BG1", "item": """On Expedition 31/32, where he helped refuel the International Space Station (ISS), Bean encountered a breakdown in the communication system between his vehicle and the ISS before arrival to the ISS. Bean was credited for leading the extravehicular activity that identified and fixed the issue, ultimately making the refuel possible."""},
    {"label": "BG2", "item": """While it is widely known that Bean holds a bachelor’s degree in Aerospace Engineering and Cross-Cultural studies, few know that he also pursued a minor in Counseling Psychology. Crewmembers have reported that Bean is a great listener and often knows exactly what to say to make others feel more comfortable."""},
    {"label": "BG3", "item": """Survey responses from Bean’s previous crew mates reveal that he has a universal sense of humor. People always understand and enjoy Bean’s jokes, so there is little risk of his humor being misinterpreted as being negative. Crew members report that this really helps to de-escalate tense situations."""},
    {"label": "BB1", "item": """Bean had a difficult time getting along with some of his co-workers at Ames. He had asked his supervisor to intervene on several occasions as they were not able to resolve the disagreements on their own."""},
    {"label": "BB2", "item": """Bean does not always plan his work well, and sometimes his pace of work is too slow. This has become problematic not only in his mission to the ISS, but also in training simulations. Often times, the maintenance work and data collection the astronauts engage in on these missions requires high levels of interdependency - this can be jeopardized if one person works at a slower pace than the rest of the crew members."""},
    {"label": "BB3", "item": """Bean has a 2-year-old daughter, and colleagues have noticed he is frustrated when he has to work late and cannot be home with her. There is worry that being away for so long on this mission will exponentially increase Bean's frustration."""},
    {"label": "BN1", "item": """Bean enjoys listening to the Beatles while performing work on his own."""},
    {"label": "BN2", "item": """Bean is an avid fan of Shakespeare and often quotes his work."""},
    {"label": "BN3", "item": """In college, Bean was on the squash team, where he met his best friend Jack. Jack now lives in Providence, Rhode Island, but they still talk on a weekly basis."""},
    {"label": "BN4", "item": """Astronaut Bean enjoys traveling and his favorite place to vacation to is in the south of France."""},
    {"label": "BN5", "item": """Bean has five siblings: one older brother, one older sister, and three younger sisters. He is closest to his younger sister, Rebecca, who is just one year younger than he is."""},
    {"label": "BN6", "item": """If chosen for this mission, Bean would be the shortest crew member at 5-feet, 5-inches tall."""},
    {"label": "CG1", "item": """Collins is accustomed to being isolated for long periods of time. He successfully completed two treks to the Antarctic in which he lived in tents and a small building for the Antarctic winter-over period. Living in small spaces did not bother him."""},
    {"label": "CG2", "item": """Collins has a passion for languages. He is fluent in English, Spanish, and French and proficient in Russian. Recently he started a class on Mandarin and already he is nearly proficient. This ability will help him interact and bond with international crew members."""},
    {"label": "CG3", "item": """Collins has participated in spacewalks to repair damaged solar panels and ammonia pump module. His peers have ranked him as the most competent crew member during their spacewalks."""},
    {"label": "CG4", "item": """Collins received the “Silver Snoopy” award for his contributions on NASA’s STS-135 mission. This award is considered to be the highest honor of all of the awards, given to the person who was the most outstanding team member, creating a team environment focused on flight safety and overall team success."""},
    {"label": "CB1", "item": """Surveys showed that Collins has snapped at coworkers on multiple occasions. In one situation, a crewmember even went so far as to say would not want to work with Collins on future missions."""},
    {"label": "CB2", "item": """Collins does not always plan his work well, and sometimes his pace of work is too slow. This has become problematic not only in his mission to the ISS, but also in training simulations. Often times, the maintenance work and data collection the astronauts engage in on these missions requires high levels of interdependency - this can be jeopardized if one person works at a slower pace than the rest of the crew members."""},
    {"label": "CB3", "item": """Recent blood work indicated that Collins may be developing above-average blood pressure. Doctors advised another assessment before making any conclusive determinations. However, if Collins does have heightened blood pressure, he would have to take extra time to rest while on the mission. This would detract from his time working on experiments, as well as his ability to do physically stressful activities."""},
    {"label": "CB4", "item": """Three weeks ago, Collins broke his ankle. As a result, he has not been training as much and the current state of his cardiovascular performance is behind compared to the other two candidates."""},
    {"label": "CB5", "item": """In one incident during a mock extravehicular activity scenario, Collins refused to follow an instruction from mission control. Fellow crew members were unsure of why he did this since the request from mission control seemed straightforward and helpful. Crewmembers reported being conflicted with how to respond, which slowed their progress on the extravehicular activity scenario. Only half of the tasks needed were completed on the simulated extravehicular activity."""},
    {"label": "CB6", "item": """An internal incident report indicates that Collins made offensive jokes to a Chinese astronaut on a previous analog space mission that made the Chinese astronaut and other crew members uncomfortable."""},
    {"label": "CN1", "item": """Collins considers himself a coffee aficionado and his favorite brand of coffee is Intelligentsia."""},
    {"label": "CN2", "item": """Collins’ childhood friend completed NASA’s astronaut candidate training program but was never selected for a space mission."""},
    {"label": "CN3", "item": """Collins enjoys completing Sudoku puzzles to relax"""},
    {"label": "CN4", "item": """Collins has a fraternal twin who works in finance in Houston, Texas."""}
]

#####AGENT 1: CMR######
cmr_KB = [
    {"item": CG1, "frequency" : 0 ,"initial": True},
    {"item": CG2, "frequency" : 0 ,"initial": True},
    {"item": CG3, "frequency" : 0 ,"initial": True},
    {"item": CG4, "frequency" : 0 ,"initial": True},
    {"item": CB4, "frequency" : 0 ,"initial": True},
    {"item": CN1, "frequency" : 0 ,"initial": True},
    {"item": CN2, "frequency" : 0 ,"initial": True},
    {"item": BG1, "frequency" : 0 ,"initial": True},
    {"item": BG2, "frequency" : 0 ,"initial": True},
    {"item": BG3, "frequency" : 0 ,"initial": True},
    {"item": BB2, "frequency" : 0 ,"initial": True},
    {"item": BB3, "frequency" : 0 ,"initial": True},
    {"item": BN1, "frequency" : 0 ,"initial": True},
    {"item": BN2, "frequency" : 0 ,"initial": True},
    {"item": AG2, "frequency" : 0 ,"initial": True},
    {"item": AG6, "frequency" : 0 ,"initial": True},
    {"item": AB1, "frequency" : 0 ,"initial": True},
    {"item": AB2, "frequency" : 0 ,"initial": True},
    {"item": AB3, "frequency" : 0 ,"initial": True},
    {"item": AB4, "frequency" : 0 ,"initial": True},
    {"item": AN1, "frequency" : 0 ,"initial": True},
    {"item": AN2, "frequency" : 0 ,"initial": True}
]
cmr = CogAgent("CMR", cmr_KB)
cog_cmr = CogChain(cmr)

#####AGENT 2: MS1#####
ms1_KB = [
    {"item": CG1, "frequency" : 0 ,"initial": True},
    {"item": CB3, "frequency" : 0 ,"initial": True},
    {"item": CB4, "frequency" : 0 ,"initial": True},
    {"item": CB5, "frequency" : 0 ,"initial": True},
    {"item": CB6, "frequency" : 0 ,"initial": True},
    {"item": CN3, "frequency" : 0 ,"initial": True},
    {"item": CN4, "frequency" : 0 ,"initial": True},
    {"item": BG1, "frequency" : 0 ,"initial": True},
    {"item": BG2, "frequency" : 0 ,"initial": True},
    {"item": BG3, "frequency" : 0 ,"initial": True},
    {"item": BB1, "frequency" : 0 ,"initial": True},
    {"item": BB2, "frequency" : 0 ,"initial": True},
    {"item": BB3, "frequency" : 0 ,"initial": True},
    {"item": BN3, "frequency" : 0 ,"initial": True},
    {"item": BN4, "frequency" : 0 ,"initial": True},
    {"item": AG1, "frequency" : 0 ,"initial": True},
    {"item": AG2, "frequency" : 0 ,"initial": True},
    {"item": AG3, "frequency" : 0 ,"initial": True},
    {"item": AG4, "frequency" : 0 ,"initial": True},
    {"item": AB1, "frequency" : 0 ,"initial": True},
    {"item": AN1, "frequency" : 0 ,"initial": True},
    {"item": AN2, "frequency" : 0 ,"initial": True},
    {"item": AN3, "frequency" : 0 ,"initial": True}
]
ms1 = CogAgent("MS1", ms1_KB)
cog_ms1 = CogChain(ms1)

#####AGENT 3: MS2#####
ms2_KB = [
    {"item": CG1, "frequency" : 0 ,"initial": True},
    {"item": CG2, "frequency" : 0 ,"initial": True},
    {"item": CG3, "frequency" : 0 ,"initial": True},
    {"item": CG4, "frequency" : 0 ,"initial": True},
    {"item": CB1, "frequency" : 0 ,"initial": True},
    {"item": CN1, "frequency" : 0 ,"initial": True},
    {"item": CN3, "frequency" : 0 ,"initial": True},
    {"item": BG1, "frequency" : 0 ,"initial": True},
    {"item": BG2, "frequency" : 0 ,"initial": True},
    {"item": BG3, "frequency" : 0 ,"initial": True},
    {"item": BB1, "frequency" : 0 ,"initial": True},
    {"item": BB2, "frequency" : 0 ,"initial": True},
    {"item": BN1, "frequency" : 0 ,"initial": True},
    {"item": BN3, "frequency" : 0 ,"initial": True},
    {"item": AG3, "frequency" : 0 ,"initial": True},
    {"item": AG4, "frequency" : 0 ,"initial": True},
    {"item": AB1, "frequency" : 0 ,"initial": True},
    {"item": AB2, "frequency" : 0 ,"initial": True},
    {"item": AB3, "frequency" : 0 ,"initial": True},
    {"item": AB4, "frequency" : 0 ,"initial": True},
    {"item": AN3, "frequency" : 0 ,"initial": True},
    {"item": AN4, "frequency" : 0 ,"initial": True}
]
ms2 = CogAgent("MS2", ms2_KB)
cog_ms2 = CogChain(ms2)

#####AGENT 4: FE######
fe_KB = [
    {"item": CG3, "frequency" : 0 ,"initial": True},
    {"item": CG4, "frequency" : 0 ,"initial": True},
    {"item": CB1, "frequency" : 0 ,"initial": True},
    {"item": CB2, "frequency" : 0 ,"initial": True},
    {"item": CB6, "frequency" : 0 ,"initial": True},
    {"item": CN2, "frequency" : 0 ,"initial": True},
    {"item": CN3, "frequency" : 0 ,"initial": True},
    {"item": BG1, "frequency" : 0 ,"initial": True},
    {"item": BG2, "frequency" : 0 ,"initial": True},
    {"item": BG3, "frequency" : 0 ,"initial": True},
    {"item": BB1, "frequency" : 0 ,"initial": True},
    {"item": BN2, "frequency" : 0 ,"initial": True},
    {"item": BN3, "frequency" : 0 ,"initial": True},
    {"item": BN5, "frequency" : 0 ,"initial": True},
    {"item": BN6, "frequency" : 0 ,"initial": True},
    {"item": AG5, "frequency" : 0 ,"initial": True},
    {"item": AB1, "frequency" : 0 ,"initial": True},
    {"item": AB2, "frequency" : 0 ,"initial": True},
    {"item": AB3, "frequency" : 0 ,"initial": True},
    {"item": AB4, "frequency" : 0 ,"initial": True},
    {"item": AN2, "frequency" : 0 ,"initial": True},
    {"item": AN3, "frequency" : 0 ,"initial": True},
    {"item": AN4, "frequency" : 0 ,"initial": True}
]
fe = CogAgent("FE", fe_KB)
cog_fe = CogChain(fe)

cog_agents = [cog_cmr, cog_ms1, cog_ms2, cog_fe]
rounds = 10
decision_options = """Candidate 1: Samuel Anders
Candidate 2: John Bean
Candidate 3: Scott Collins"""
decision_rule = 'majority'
discussion_task = """ DISCUSSION TASK: You work as a member of NASA’s Astronaut Crew Composition team. Your team analyzes all of the information obtained during astronaut selection and training - including test scores, analog performance measures, expert observations, peer evaluations, and medical  records. Armed with this information, your team makes two kinds of evaluations. The first evaluation is to determine which astronauts are ready for flight and which are not. Of those who are deemed to be flight ready, your team composes entire crews for each mission. In this second evaluation, you consider the complementarity and compatibility of the astronauts as a team to select the 4, 5, or 6  astronauts (depending on the mission) who will perform best as individuals, and as a crew. While composing crews for missions on the International Space Station has become routine, your team just received a special assignment from the Mission Planning Directorate that is anything but routine.  
The Mars mission has been fast-tracked. Instead of the 2033 launch date that NASA had been aiming for, the launch date is being moved up to 2020. Intensive crew training for this unprecedented and bold journey must begin immediately. A 5-member crew will embark on this 3 year journey to Mars. This a truly international endeavor: the Russian, European, Indian, and Chinese Space Agencies will each select one astronaut for the mission. NASA will select the 5th crew member - an American astronaut - to join this international crew.  
The crew members from the other countries have backgrounds in engineering, botany, geology and medicine. The crew still needs a flight engineer. 
Your team was able to quickly narrow the field down to three veteran astronauts: Anders, Bean, and Collins. Each of these three have experience as a flight engineer on the ISS, have the necessary basic technical skills for the flight engineer position, meet basic requirements for the mission including height, Body Mass Index, and have passed a mental health screening. Now that you know the other potential crew members it is necessary for your team to determine which of the crew members will be the greatest asset on this particular mission.  
The 3-year mission to Mars will be demanding. The success of the Mars mission will require the 5-person crew to live and work together in extremely close quarters, while isolated from the usual sources of social support - friends and family - for extended periods of time. It will require that the crew can adapt to the unknown and be able to handle whatever challenges will come their way. Once they arrive at Mars, the crew will have to complete complex feats such as landing and extravehicular activities. Because of a significant communication delay with Earth of up to 22 minutes each way, the crew will have to work autonomously. Additionally, the crew of the Mars mission consists of individuals representing multiple nationalities, making strong interpersonal skills all the more critical to the success of the mission.  
The international space consortium has agreed to announce the names of the crew members from each of the 5 countries in just 10 days from now. Your team must deliver a recommendation for whom should be the American astronaut; years of hard work (and millions of dollars) rest on this decision.  
To guide your difficult decision, you have compiled information from the personnel file for each candidate. The personnel files for each candidate are detailed and include information such as their performance scores and ranking on various training tasks, biographical information, evaluations and questionnaires completed by  supervisors and individuals with whom they worked on prior trainings and missions, and questionnaires completed by the candidate and his family. A few human resource assistant have been working through the personnel files and have prepared briefs for you. Your team must now come together and discuss who should be selected for the mission.   
Remember, the success of the mission to Mars depends on your team. Choose quickly, but wisely!
"""
astronaut_candidate = Conversation(cog_agents, discussion_task, rounds, decision_options, decision_rule, knowledge_bank)

astronaut_candidate.run_convo()

with open("agent_states.txt", "w") as states_file:
    for agent in astronaut_candidate.cog_agents:
        states_file.write(f"----- {agent.cog_agent.name} States -----\n")
        for element in agent.cog_agent.state:
            states_file.write(f"{element}\n")
        states_file.write("\n")  # Add a newline after each agent's states